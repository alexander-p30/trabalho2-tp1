var searchData=
[
  ['primeiro_20trabalho_20da_20matéria_20de_20técnicas_20de_20programação_201_0',['Primeiro trabalho da matéria de Técnicas de Programação 1',['../md_README.html',1,'']]]
];
